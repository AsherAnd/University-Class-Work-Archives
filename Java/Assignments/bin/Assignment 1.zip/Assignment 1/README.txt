Prods: works as intended
Custs: works as intended
Books: works as intended
Newcusts:works as intended
Order: works as intended
Orders: works as intended
Orderbook: works as intended
Ship: works as intended
Shipped: works as intended
Cancel: works as intended
Custorders: works as intended
Sortbyprice: works as intended
Sortbyname: works as intended
Sortcust: works as intended
shoes: works as intended
ordershoes: works as intended